const express = require("express");
const db = require("../config/db");

const router = express.Router();

// Get all staff members
router.get("/", (req, res) => {
    db.query("SELECT * FROM Staff", (err, result) => {
        if (err) return res.status(500).json(err);
        res.json(result);
    });
});

// Add new staff member
router.post("/", (req, res) => {
    const { firstname, email, phone, department } = req.body;
    db.query("INSERT INTO Staff (firstname, email, phone, department) VALUES (?, ?, ?, ?)", 
    [firstname, email, phone, department], (err, result) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Staff added successfully!" });
    });
});
router.delete("/:id", (req, res) => {
    const { id } = req.params;
    db.query("DELETE FROM Staff WHERE employeeid=?", 
    [id], (err, result) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Staff deleted successfully!" });
    });
});
router.put("/:id", (req, res) => {
    const { id } = req.params;
    const { firstname, email, phone, department } = req.body;
    db.query("UPDATE Staff SET firstname=?, email=?, phone=?, department=? WHERE employeeid=?", 
    [firstname, email, phone, department,id], (err, result) => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Staff updated successfully!" });
    });
});

module.exports = router;
