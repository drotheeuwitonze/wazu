const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../config/db");

const router = express.Router();

// User login
router.post("/login", (req, res) => {
    const { username, password } = req.body;
    db.query("SELECT * FROM User WHERE username = ?", [username], (err, results) => {
        if (err || results.length === 0) return res.status(400).json({ message: "Invalid username" });

        const user = results[0];
        if (!bcrypt.compareSync(password, user.password)) {
            return res.status(400).json({ message: "Invalid password" });
        }

        res.json({ message: "Login successful!",user });
    });
});

router.post("/register", (req,res)=>{
    const { username, password } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10)
    db.query("INSERT INTO user (username,password) VALUES(?,?)", [username,hashedPassword], (err,data)=>{
        if(err) return res.status(500).json("DB ERROR");
        return res.status(201).json({message:"Your account created successfully"})
    })
})

module.exports = router;
