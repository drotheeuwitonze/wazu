class Staff {
    constructor(employeeid, firstname, department, email) {
        this.employeeid = employeeid;
        this.firstname = firstname;
        this.department = department;
        this.email = email;
    }
}

module.exports = Staff;
