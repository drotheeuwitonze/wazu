import axios from "axios";

const api = axios.create({
    baseURL: "http://localhost:5000",
});

export const loginUser = (userData) => api.post("/auth/login", userData);
export const registerUser = (userData) => api.post("/auth/register", userData);
export const registerStaff = (staffData) => api.post("/staff", staffData);
export const getStaff = () => api.get("/staff");

export default api;
