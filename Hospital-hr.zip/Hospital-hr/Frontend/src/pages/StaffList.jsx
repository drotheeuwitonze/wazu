import { useEffect, useState } from "react";
import axios from "axios";

function StaffList() {
    const [staff, setStaff] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:5000/staff")
            .then((res) => setStaff(res.data))
            .catch((err) => console.error("Error fetching staff", err));
    }, []);

    return (
        <div>
            <h2 className="text-xl font-bold">Staff Members</h2>
            <ul>
                {staff.map((member) => (
                    <li key={member.employeeid}>
                        {member.firstname} - {member.department}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default StaffList;
