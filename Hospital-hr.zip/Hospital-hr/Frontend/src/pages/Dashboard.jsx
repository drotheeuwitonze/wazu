import { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Dashboard() {
    const [staff, setStaff] = useState([]);
    const [activePage, setActivePage] = useState("dashboard");
    const [newStaff, setNewStaff] = useState({ firstname: "", department: "", phone: "" });
    const [editingStaff, setEditingStaff] = useState(null);
    const user = JSON.parse(localStorage.getItem("user"))
    const navigate = useNavigate()

    useEffect(() => {
        fetchStaff();
    }, []);

    const fetchStaff = () => {
        axios.get("http://localhost:5000/staff")
            .then((res) => setStaff(res.data))
            .catch((err) => console.error("Error fetching staff", err));
    };

    const addStaff = () => {
        axios.post("http://localhost:5000/staff", newStaff)
            .then(() => {
                fetchStaff();
                setNewStaff({ firstname: "", department: "", phone: "" });
                setActivePage("staff");
            })
            .catch(err => console.error("Error adding staff", err));
    };

    const deleteStaff = (id) => {
        axios.delete(`http://localhost:5000/staff/${id}`)
            .then(() => fetchStaff())
            .catch(err => console.error("Error deleting staff", err));
    };

    const updateStaff = () => {
        axios.put(`http://localhost:5000/staff/${editingStaff.employeeid}`, editingStaff)
            .then(() => {
                fetchStaff();
                setEditingStaff(null);
            })
            .catch(err => console.error("Error updating staff", err));
    };
    const handleLogout = () =>{
        localStorage.removeItem("user")
        toast.success("You logged out!")
        navigate("/")
    }

    return user ? (
        <div className="flex h-screen bg-gray-100">
            {/* Sidebar */}
            <aside className="w-64 bg-blue-900 text-white p-6">
                <h2 className="text-xl font-bold">Admin Panel</h2>
                <nav className="mt-6">
                    <ul>
                        <li className={`py-2 hover:bg-blue-700 rounded px-4 cursor-pointer ${activePage === "dashboard" ? "bg-blue-700" : ""}`}
                            onClick={() => setActivePage("dashboard")}>Dashboard</li>
                        <li className={`py-2 hover:bg-blue-700 rounded px-4 cursor-pointer ${activePage === "staff" ? "bg-blue-700" : ""}`}
                            onClick={() => setActivePage("staff")}>Staff</li>
                        <li className={`py-2 hover:bg-blue-700 rounded px-4 cursor-pointer ${activePage === "newStaff" ? "bg-blue-700" : ""}`}
                            onClick={() => setActivePage("newStaff")}>New Staff</li>
                        <li className={`py-2 hover:bg-blue-700 rounded px-4 cursor-pointer ${activePage === "settings" ? "bg-blue-700" : ""}`}
                            onClick={() => setActivePage("settings")}>Settings</li>
                    </ul>
                </nav>
            </aside>

            {/* Main Content */}
            <div className="flex-1 flex flex-col">
                {/* Top Bar */}
                <header className="bg-white p-4 shadow-md flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-gray-800">Hospital Dashboard</h1>
                    <div className="flex items-center">
                        <span className="text-gray-600 mr-4">Welcome, {user.username}</span>
                        {/* <img src="https://via.placeholder.com/40" alt="User avatar" className="rounded-full" /> */}
                        <button onClick={handleLogout} className="px-6 py-2 text-white bg-red-700 rounded-lg shadow-lg cursor-pointer">Logout</button>
                    </div>
                </header>

                {/* Dynamic Content Rendering */}
                <main className="p-6">
                    {activePage === "dashboard" && (
                        <h2 className="text-lg font-semibold">Welcome to the Dashboard</h2>
                    )}

                    {activePage === "staff" && (
                        staff.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                                {staff.map((member) => (
                                    <div
                                        key={member.employeeid}
                                        className="bg-white p-6 rounded-lg shadow-md flex flex-col items-center text-center"
                                    >
                                        <h2 className="text-xl font-semibold text-gray-700">{member.firstname}</h2>
                                        <p className="text-gray-500">{member.department}</p>
                                        <p className="text-gray-600">{member.phone}</p>
                                        <div className="space-x-4">
                                        <button
                                            onClick={() => setEditingStaff(member)}
                                            className="bg-green-600 text-white px-3 py-1 rounded mt-2">Edit</button>
                                        <button
                                            onClick={() => deleteStaff(member.employeeid)}
                                            className="bg-red-600 text-white px-3 py-1 rounded mt-2">Delete</button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-600">No staff members found.</p>
                        )
                    )}

                    {activePage === "newStaff" && (
                        <div>
                            <h2 className="text-lg font-semibold mb-4">Add New Staff Member</h2>
                            <div className="grid grid-cols-3 gap-4">
                                <input type="text" placeholder="First Name" className="p-2 border rounded"
                                    value={newStaff.firstname}
                                    onChange={(e) => setNewStaff({ ...newStaff, firstname: e.target.value })} />
                                <input type="text" placeholder="Department" className="p-2 border rounded"
                                    value={newStaff.department}
                                    onChange={(e) => setNewStaff({ ...newStaff, department: e.target.value })} />
                                <input type="text" placeholder="Phone" className="p-2 border rounded"
                                    value={newStaff.phone}
                                    onChange={(e) => setNewStaff({ ...newStaff, phone: e.target.value })} />
                                <button onClick={addStaff} className="bg-blue-600 text-white px-4 py-2 rounded">Add Staff</button>
                            </div>
                        </div>
                    )}

                    {activePage === "settings" && (
                        <div>
                            <h2 className="text-lg font-semibold mb-4">Settings</h2>
                            <p className="text-gray-600">Feature coming soon!</p>
                        </div>
                    )}
                </main>

                {/* Edit Staff Modal */}
                {editingStaff && (
                    <div className="fixed inset-0 bg-[rgba(0,0,0,0.8)] flex items-center justify-center">
                        <div className="bg-white p-6 rounded shadow-lg w-96">
                            <h2 className="text-lg font-semibold mb-4">Edit Staff Member</h2>
                            <input type="text" placeholder="First Name" className="p-2 border rounded w-full mb-2"
                                value={editingStaff.firstname}
                                onChange={(e) => setEditingStaff({ ...editingStaff, firstname: e.target.value })} />
                            <input type="text" placeholder="Department" className="p-2 border rounded w-full mb-2"
                                value={editingStaff.department}
                                onChange={(e) => setEditingStaff({ ...editingStaff, department: e.target.value })} />
                            <input type="text" placeholder="Phone" className="p-2 border rounded w-full mb-2"
                                value={editingStaff.phone}
                                onChange={(e) => setEditingStaff({ ...editingStaff, phone: e.target.value })} />
                            <button onClick={updateStaff} className="bg-green-600 text-white px-4 py-2 rounded">Update</button>
                            <button onClick={() => setEditingStaff(null)} className="bg-gray-400 text-white px-4 py-2 rounded ml-2">Cancel</button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    ) : (
        <div className="flex items-center justify-center min-h-screen">
            <div className="flex items-center flex-col">
                <h1 className="text-4xl mb-4">Restricted page</h1>
                <p className="text-lg">You have to login to view this page.</p>
                <Link className="px-6 py-2 rounded-lg shadow-lg text-white cursor-pointer bg-emerald-500 mt-4" to="/">Login</Link>
            </div>
        </div>
    );
}

export default Dashboard;
