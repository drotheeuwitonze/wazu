import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Dashboard from "./pages/Dashboard";
import StaffForm from "./components/staffForm";
import Register from "./components/Register";
import { ToastContainer } from "react-toastify";

function App() {
    return (
        <BrowserRouter>
        <ToastContainer
        position="top-center"
        autoClose={2000}
        />
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/register" element={<StaffForm />} />
                <Route path="/admin-register" element={<Register />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
