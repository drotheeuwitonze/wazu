import { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Login() {
    const [user, setUser] = useState({ username: "", password: "" });
    const navigate = useNavigate();

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await axios.post("http://localhost:5000/auth/login", user);
            toast.success(res.data.message);
            navigate("/dashboard");
            localStorage.setItem("user", JSON.stringify(res.data.user))
        } catch (error) {
            toast.error("Login failed!", error);
        }
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-100">
            <form onSubmit={handleSubmit} className="w-full max-w-sm bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-2xl font-semibold text-center mb-4">Login</h2>
                <div className="mb-4">
                    <label className="block text-gray-700 font-medium">Username</label>
                    <input 
                        type="text" 
                        name="username" 
                        placeholder="Enter username" 
                        onChange={handleChange} 
                        className="w-full p-2 border border-gray-300 rounded mt-1"
                    />
                </div>
                <div className="mb-6">
                    <label className="block text-gray-700 font-medium">Password</label>
                    <input 
                        type="password" 
                        name="password" 
                        placeholder="Enter password" 
                        onChange={handleChange} 
                        className="w-full p-2 border border-gray-300 rounded mt-1"
                    />
                </div>
                <button 
                    type="submit" 
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
                >
                    Login
                </button>
                <p className="text-center text-gray-600 mt-3">
                    New here? <Link to="/admin-register" className="text-blue-500 hover:underline">Register</Link>
                </p>
            </form>
        </div>
    );
}

export default Login;
