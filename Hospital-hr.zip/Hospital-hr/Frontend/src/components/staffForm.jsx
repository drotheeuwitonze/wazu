import { useState } from "react";
import axios from "axios";

function StaffForm() {
    const [staff, setStaff] = useState({
        firstname: "",
        email: "",
        phone: "",
        department: ""
    });

    const handleChange = (e) => {
        setStaff({ ...staff, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:5000/staff", staff);
            alert("Staff registered successfully!");
        } catch (error) {
            console.error("Error registering staff", error);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="p-4 bg-white rounded shadow-md">
            <input type="text" name="firstname" placeholder="First Name" onChange={handleChange} className="border p-2" />
            <input type="email" name="email" placeholder="Email" onChange={handleChange} className="border p-2" />
            <button type="submit" className="bg-blue-500 text-white p-2">Submit</button>
        </form>
    );
}

export default StaffForm;
